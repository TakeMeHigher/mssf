
e = 'aa\dd\cc'
print(e.split('\\'))