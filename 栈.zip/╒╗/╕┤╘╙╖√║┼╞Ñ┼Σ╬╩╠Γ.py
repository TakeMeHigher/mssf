def fzfhpp(str):
    """
    复杂符号匹配问题
    :param str:
    :return:
    """
    ll = []
    blance = True
    for i in str:
        if i in "([{":
            ll.append(i)
        elif i in ')]}' and len(ll) > 0:
            bb = ll.pop()
            if not check(bb, i):
                blance = False
                break
            continue

    if blance and len(ll) == 0:
        print('ok')
    else:
        print('no')


def check(pop_i, cur_i):
    str_z = '([{'
    str_f = ')]}'
    return str_z.index(pop_i) == str_f.index(cur_i)



fzfhpp('{{([][])}()}')
fzfhpp('[{()]')