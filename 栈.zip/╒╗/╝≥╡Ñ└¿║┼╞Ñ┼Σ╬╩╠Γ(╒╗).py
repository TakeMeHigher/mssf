from 栈.stock import Stack


def khpp(ss):
    """
    括号匹配问题
    :param ss: 要匹配的字符串
    :return:
    """
    ll = []
    for i in ss:
        if i == '(':
            ll.append(i)
        elif i == ')' and len(ll) > 0:
            ll.pop()

    if len(ll) == 0:
        print('ok')
    else:
        print('no')


khpp('(((()))')
