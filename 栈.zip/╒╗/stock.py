class Stack(object):

    def __init__(self):
        self.item = []

    def push(self, data):
        self.item.append(data)

    def pop(self):
        self.item.pop()

    def is_empty(self):
        return len(self.item) == 0

    def peek(self):
        return self.item[len(self.item) - 1]

    def size(self):
        return len(self.item)
